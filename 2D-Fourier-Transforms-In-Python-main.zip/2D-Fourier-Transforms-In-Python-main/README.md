# 2D Fourier Transforms In Python

This repo is linked to the article ["How to Create Any Image Using Only Sine Functions | 2D Fourier Transforms in Python"](https://thepythoncodingbook.com/2021/08/30/2d-fourier-transform-in-python-and-fourier-synthesis-of-images/) on The Python Coding Book Blog.

It contains sample images used in the article, and the final version of the code described in the article
